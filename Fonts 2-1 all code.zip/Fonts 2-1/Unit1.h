//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TRichEdit *RichEdit1;
        TRichEdit *RichEdit2;
        TBitBtn *BitBtn1;
        TFontDialog *FontDialog1;
        TLabel *Label1;
        TRichEdit *RichEdit3;
        TComboBox *ComboBox2;
        TUpDown *UpDown1;
        TRichEdit *RichEdit4;
        TComboBox *ComboBox3;
        TUpDown *UpDown2;
        TListBox *ListBox1;
        TEdit *Edit1;
        TBitBtn *BitBtn2;
        TEdit *Edit2;
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall RichEdit2MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall RichEdit2MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall RichEdit1MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall BitBtn3Click(TObject *Sender);
        void __fastcall UpDown1Click(TObject *Sender, TUDBtnType Button);
        void __fastcall ComboBox2Change(TObject *Sender);
        void __fastcall UpDown2Click(TObject *Sender, TUDBtnType Button);
        void __fastcall ListBox1Click(TObject *Sender);
        void __fastcall BitBtn2Click(TObject *Sender);
        void __fastcall ComboBox3Change(TObject *Sender);
        void __fastcall RichEdit1MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
